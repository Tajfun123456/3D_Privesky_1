
  # E-shop Design for Fox Charms

  This is a code bundle for E-shop Design for Fox Charms. The original project is available at https://www.figma.com/design/jkuPcc7jAL5fIy0jIvheWo/E-shop-Design-for-Fox-Charms.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  